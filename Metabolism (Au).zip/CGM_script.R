## CGM Example
# Date: October 13, 2021
# CSEP 2021: Data Science for the Modern Exercise Physiologist

# First thing - questions about the major tutorial section?


# Open your libraries
library(tidyverse)

# Open your data
df <- read.csv('CGMdata.csv', skip = 11)

# Explore your data
str(df)

# What do we need to adjust?
# We can filter out only rows with glucose values
df.adjusted <- df %>% 
  filter(Sensor.Glucose..mmol.L. != "NA")

# We can simplify the sheet by getting rid of extra data
df.adjusted <- df.adjusted %>% 
  select(1:10)

# We can make an easier time column
df.adjusted <- df.adjusted %>% 
  mutate(time.min = seq(1,dim(df)[1]*5,5))

# We can explore our data
ggplot(data = df.adjusted, aes(x = time.min, y = Sensor.Glucose..mmol.L.))+
  geom_point()

# How might we adjust this graph?

# What features would we want to highlight?
# High glucose example
df.adjusted <- df.adjusted %>% 
  mutate(high = case_when(
    Sensor.Glucose..mmol.L. >= 6 ~ TRUE,
    Sensor.Glucose..mmol.L. < 6 ~ FALSE
  ))

ggplot(data = df.adjusted, aes(x = time.min, y = Sensor.Glucose..mmol.L., color = high))+
  geom_point()

# Day example
ggplot(data = df.adjusted, aes(x = time.min, y = Sensor.Glucose..mmol.L.))+
  geom_point()+
  geom_vline(xintercept = 1440)+
  geom_vline(xintercept = 2880)
