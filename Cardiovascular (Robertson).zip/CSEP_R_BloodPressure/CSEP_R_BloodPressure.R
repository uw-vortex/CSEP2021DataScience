# Blood Pressure Example
# CSEP 2021: Data Science for the Modern Exercise Physiologist
# Andrew Robertson 
# 2021-10-13


# Libraries ----
library(tidyverse) # data organization/wrangling + ggplot
library(plotly) # interactive plots

# Import data ----
# identify data files from within home directory (i.e., ".") 
df_list_young <- list.files(".", pattern = "Young")
df_list_old <- list.files(".", pattern = "Old")


# import data from individual files for each participant

# initialize a table for all YOUNG data with 4 columns ID, Age_Group, Time, Pressure
young <- tibble(ID = as.factor(NA),             # "factor" is a grouping variable
                Age_Group = as.factor(NA), 
                Time = as.numeric(NA),          # "numeric" is a continuous variable
                MAP = as.numeric(NA))

# sequentially add each of the data files from the YOUNG list into the main table
for (i in 1:length(df_list_young)){
  
  #extract key information from the filename by manipulation strings (a sequence of characters)
  filename_base <- str_remove(df_list_young[i], pattern = ".csv")   # removes the file extension to allow working with the filename components
  id <- str_split(filename_base, pattern = "_")[[1]][1]             # separates components of the filename based on pattern. First component is ID
  group <- str_split(filename_base, pattern = "_")[[1]][2]          # separates components of the filename based on pattern. Second component is age grouping
  
  temp_df <- read_csv(df_list_young[i])                             ## open a single file ----
  temp_df <- temp_df %>%                
    mutate(ID = id) %>%                                             # link the ID number to the data, column added to end 
    mutate(Age_Group = group) %>%                                   # link the age grouping to the data, column added to end
    relocate(Time:MAP, .after = Age_Group)                          # rearrange the column order to match the main table
  
  young <- bind_rows(young, temp_df)                                # appends the new data onto the main table
}
young <- young[-1,]



# repeat for older participants
old <- tibble(ID = as.factor(NA), 
              Age_Group = as.factor(NA), 
              Time = as.numeric(NA), 
              MAP = as.numeric(NA))

# sequentially add each of the data files from the YOUNG list into the main table
for (i in 1:length(df_list_old)){
  
  #extract key information from the filename by manipulation strings (a sequence of characters)
  filename_base <- str_remove(df_list_old[i], pattern = ".csv")     # removes the file extension to allow working with the filename components
  id <- str_split(filename_base, pattern = "_")[[1]][1]             # separates components of the filename based on pattern. First component is ID
  group <- str_split(filename_base, pattern = "_")[[1]][2]          # separates components of the filename based on pattern. Second component is age grouping
  
  temp_df <- read_csv(df_list_old[i])                               # open a single file
  temp_df <- temp_df %>%                
    mutate(ID = id) %>%                                             # link the ID number to the data, column added to end
    mutate(Age_Group = group) %>%                                   # link the age grouping to the data, column added to end
    relocate(Time:MAP, .after = Age_Group)                          # rearrange the column order to match the main table
  
  old <- bind_rows(old, temp_df)                                    # appends the new data onto the main table
}
old <- old[-1,]


## bind young and old data tables together ----
combined <- bind_rows(young, old)

# Plotting ----
## create a plot of individual responses ----
plot_MAP <- combined %>% 
  ggplot(., aes(x = Time, y = MAP, colour = ID)) +              # aes defines the plot aesthetics. i.e., which variables you want to use where 
  geom_line() +
  scale_y_continuous(name = "Mean Arterial Pressure (mmHg)") +  # adjust y-axis label
  scale_x_continuous(name = "Time (s)") +                       # adjust x-axis label
  theme_bw()
plot_MAP # the plot above is saved as a variable. Recall the plot to visualize.

# how else can we plot this data?



# the following are alternative plots with subtle changes from above. New lines (in addition to above) are bracketed with ##


# separate young and old groups into subplots (or facets)
plot_MAP_by_age <- combined %>%
  ggplot(., aes(x = Time, y = MAP, colour = ID)) +
  geom_line() +
  scale_y_continuous(name = "Mean Arterial Pressure (mmHg)") +
  scale_x_continuous(name = "Time (s)") +
  ##  
  facet_wrap(.~Age_Group, strip.position = "top", scales = "fixed") +
  ##  
  theme_bw()
plot_MAP_by_age


# fix order of Age_Group presentation
combined <- combined %>% 
  mutate(Age_Group = factor(Age_Group, levels = c("Young", "Old"))) # sets order as "young" before "old"

# redo plot above with new line to give more room on the left margin of the plot
plot_MAP_by_age_sorted <- combined %>%
  ggplot(., aes(x = Time, y = MAP, colour = ID)) +
  geom_line() +
  scale_y_continuous(name = "Mean Arterial Pressure (mmHg)") +
  scale_x_continuous(name = "Time (s)") +
  facet_wrap(.~Age_Group, strip.position = "top", scales = "fixed") +
  theme_bw() +
#
  theme(plot.margin = unit(c(0.5, 0.5, 0.5, 1.5), "cm"))
#
plot_MAP_by_age_sorted

# the plotly library allows us to make the plot interactivev for teaching/presentations
ggplotly(plot_MAP_by_age_sorted)


# identify stages of exercise
combined$stage <- ifelse(combined$Time <300, "Rest", ifelse(combined$Time < 1800, "Exercise", "Recovery"))
combined$stage <- as_factor(combined$stage)

# add vertical lines to separate stages of exercise.
# add text to highlight parts of the plot
plot_MAP_by_age_sorted_with_stages <- combined %>% 
  ggplot(., aes(x = Time, y = MAP, colour = ID)) +
  geom_line() +
  scale_y_continuous(name = "Mean Arterial Pressure (mmHg)") +
  scale_x_continuous(name = "Time (s)") +
  facet_wrap(.~Age_Group, strip.position = "top", scales = "fixed") +
  #
  geom_vline(xintercept = c(300, 1800), linetype = "dotted", size = 1) +
  annotate("text", x = 1000, y = 150, label = "This is Exercise!!!")+
  #
  theme_bw()

plot_MAP_by_age_sorted_with_stages


## plot group means only ----

# first summarize the data into means and standard deviations across groups at each time point
group_mean_SD <- combined %>% 
  group_by(Age_Group, Time) %>% 
  summarize(MAP_mean = mean(MAP),
            MAP_sd = sd(MAP), .groups = "drop")

# two alternatives for plotting stadard deviation
      # geom_error bar is traditional but creates a problem with overlapping error bars
      # geom_ribbon allows you to create transparency in the error bars to visualize overlap
plot_mean_MAP_by_age <- group_mean_SD %>% 
  ggplot(., aes(x = Time, group = Age_Group)) +
  #
  geom_errorbar(aes(ymin = MAP_mean-MAP_sd, ymax = MAP_mean+MAP_sd, colour = Age_Group), width = 0.05) +
  #geom_ribbon(aes(ymin = MAP_mean-MAP_sd, ymax = MAP_mean+MAP_sd, fill = Age_Group), alpha = 0.5) +
  #
  geom_line(aes(y= MAP_mean, group = Age_Group), size = 1, colour = "black") +
  theme_bw()+ 
  scale_y_continuous(name = "Mean Arterial Pressure (mmHg)") +
  scale_x_continuous(name = "Time (s)")

plot_mean_MAP_by_age


# Tables ----
# example - Making a Table for you paper
# Note: this is a bit more complicated coding than is intended for this tutorial but I wanted to give you an example of the utility
# setting up your code at the beginning of your project to save you time (potentially unintended errors/typos) as you move toward 
# publication


# call new libraries specializing in tables
library(knitr)
library(kableExtra)

# average individual data within exercise stage, then average group by exercise stage
Group_BP <- combined %>% 
  group_by(stage, Age_Group, ID) %>% 
  summarize(MAP_indy = mean(MAP, na.rm = T), 
            .groups = 'drop') %>% 
  group_by(stage, Age_Group) %>% 
  summarize(n = n(), 
            MAP_mean = mean(MAP_indy, na.rm = T), 
            MAP_SD = sd(MAP_indy, na.rm = T), 
            .groups = 'drop') 


# for table formatting combine Mean and SD (with SD in parentheses)
Group_BP$BPmnsd_parenth <- str_c(format(unlist(round(Group_BP$MAP_mean,1)), trim = F), " (", format(unlist(round(Group_BP$MAP_SD,1)), trim = F),")")


# obtain sample sizes from each measurement
young_n <- Group_BP %>% filter(Age_Group == "Young" & stage == "Rest") %>% pull(n)
old_n <- Group_BP %>% filter(Age_Group == "Old" & stage == "Rest") %>% pull(n)


# create columns for table: one column for each exercise stage
gp_rest <- Group_BP %>% 
  filter(stage == "Rest") %>% 
  rename(table_data_rest = BPmnsd_parenth)

gp_exercise <- Group_BP %>% 
  filter(stage == "Exercise") %>% 
  rename(table_data_exercise = BPmnsd_parenth) 

gp_recovery <- Group_BP %>% 
  filter(stage == "Recovery") %>% 
  rename(table_data_recovery = BPmnsd_parenth) 

# join columns together
table_data <- inner_join(gp_rest[,c(2,6)], gp_exercise[,c(2,6)], by = "Age_Group")
table_data <- inner_join(table_data, gp_recovery[,c(2,6)], by = "Age_Group")
table_data$variable <- "Mean Arterial Pressure"
table_data <- table_data %>% relocate(variable)

table_data_n <- tibble(variable = c("n", ""),
                       Age_Group = c("Young", "Old"),
                       table_data_rest = c(young_n, old_n),
                       table_data_exercise = c(young_n, old_n),
                       table_data_recovery = c(young_n, old_n))
table_data <- rbind(table_data_n, table_data)
table_data$variable[4] = ""


# create table - this can be saved as html and copied and pasted into your Word document or saved as a separate pdf
table_data %>%
  kable(col.names = c("Variable", "Age Group", "Rest", "Exercise", "Recovery"),
        caption = "Table 1. Mean Arterial Pressure by Age and Exercise Stage") %>%
  kable_classic_2(full_width = F) %>%
  add_header_above(c(" " = 2, "Exercise Stage" = 3)) %>%                          # add multiple header rows
  footnote(general = "Mean (SD) values reported.", general_title = "")            # add footnote


# Collect more data ----
# Now keep collecting more data! Move files from "additional data" folder into the main folder.
# Watch how your figures and tables are updated.

# Good luck with your adventures in R !!!!
# Google can a good resource if you ask the right question ... but answers can very so be cautious